# ¡Haz que tu Crush se Enamore con este Proyecto en HTML, CSS y JS! 💕😱
### Video del tutorial: [https://youtu.be/G39TzJRPt-M](https://youtu.be/G39TzJRPt-M)

![image](https://github.com/user-attachments/assets/2e2636d8-accb-48ba-9740-693050696ba1)
![image](https://github.com/user-attachments/assets/51ce2674-51d2-45b8-bd0c-5e98f739980a)
![image](https://github.com/user-attachments/assets/d26877f8-9193-4e26-a363-8f02eaa6f45c)

